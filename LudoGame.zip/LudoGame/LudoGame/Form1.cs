﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LudoGame
{
    public partial class Form1 : Form
    {
        bool reallyClose = true;
        bool isAutomated;
        int playerWithComputerIdx;
        int firstPlayerIdx;
        int secondPlayerIdx;

        int step = 35;
        int amountOfSteps;
        int counter = 0;

        Point greenBase = new Point(211, 71);
        Point greenHomeEntrance = new Point(36, 211);
        Point blueBase = new Point(281, 421);
        Point blueHomeEntrance = new Point(456, 281);

        List<PictureBox> greenChipsInArea = new List<PictureBox>();
        List<PictureBox> greenChipsOutOfArea = new List<PictureBox>();
        List<PictureBox> allGreenChips = new List<PictureBox>();
        Dictionary<PictureBox, bool> greenDictChipsLoop = new Dictionary<PictureBox, bool>();
        Dictionary<PictureBox, Point> greenDictChipsBasePos = new Dictionary<PictureBox, Point>();

        List<PictureBox> blueChipsInArea = new List<PictureBox>();
        List<PictureBox> blueChipsOutOfArea = new List<PictureBox>();
        List<PictureBox> allBlueChips = new List<PictureBox>();
        Dictionary<PictureBox, bool> blueDictChipsLoop = new Dictionary<PictureBox, bool>();
        Dictionary<PictureBox, Point> blueDictChipsBasePos = new Dictionary<PictureBox, Point>();

        List<PictureBox> greenPlayedChips = new List<PictureBox>();
        List<PictureBox> bluePlayedChips = new List<PictureBox>();
        List<string> allPlayers = new List<string>();
        List<bool> playersInGame = new List<bool>();
        List<bool> playersLoop = new List<bool>();

        List<int> excludeForMoveChip = new List<int>();
        List<int> excludeForPlayersChips = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBoxGreen.Parent = pictureBoxDesk;
            pictureBoxGreen1.Parent = groupBoxGreen;
            pictureBoxGreen2.Parent = groupBoxGreen;
            pictureBoxGreen3.Parent = groupBoxGreen;
            pictureBoxGreen4.Parent = groupBoxGreen;
            pictureBoxGreen1.Location = new Point(27, 30);
            pictureBoxGreen2.Location = new Point(78, 30);
            pictureBoxGreen3.Location = new Point(27, 86);
            pictureBoxGreen4.Location = new Point(78, 86);
            foreach (PictureBox c in groupBoxGreen.Controls.OfType<PictureBox>().ToArray())
            {
                greenChipsInArea.Add(c);
            }

            groupBoxBlue.Parent = pictureBoxDesk;
            pictureBoxBlue1.Parent = groupBoxBlue;
            pictureBoxBlue2.Parent = groupBoxBlue;
            pictureBoxBlue3.Parent = groupBoxBlue;
            pictureBoxBlue4.Parent = groupBoxBlue;
            pictureBoxBlue1.Location = new Point(27, 30);
            pictureBoxBlue2.Location = new Point(78, 30);
            pictureBoxBlue3.Location = new Point(27, 86);
            pictureBoxBlue4.Location = new Point(78, 86);
            foreach (PictureBox c in groupBoxBlue.Controls.OfType<PictureBox>().ToArray())
            {
                blueChipsInArea.Add(c);
            }
        }

        // chips enable/unable____________________________________________________________________________________________________________

        private void enableAllPlayersChips(string color)
        {
            buttonSkip.Enabled = true;
            foreach (Control c in pictureBoxDesk.Controls.OfType<Panel>().ToList())
            {
                foreach (Control c2 in c.Controls.OfType<PictureBox>().ToList())
                {
                    c2.Enabled = false;
                }
            }
            if (amountOfSteps == 6)
            {
                switch (color)
                {
                    case "green":
                        foreach (var elem in greenChipsOutOfArea)
                        {
                            if (!greenPlayedChips.Contains(elem))
                            {
                                elem.Enabled = true;
                            }
                        }

                        foreach (var elem in greenChipsInArea)
                        {
                            if (!greenPlayedChips.Contains(elem))
                            {
                                elem.Enabled = true;
                            }
                        }
                        break;
                    case "blue":
                        foreach (var elem in blueChipsOutOfArea)
                        {
                            if (!bluePlayedChips.Contains(elem))
                            {
                                elem.Enabled = true;
                            }
                        }

                        foreach (var elem in blueChipsInArea)
                        {
                            if (!bluePlayedChips.Contains(elem))
                            {
                                elem.Enabled = true;
                            }
                        }
                        break;
                }
            }
            else
            {
                switch (color)
                {
                    case "green":
                        foreach (var elem in greenChipsOutOfArea)
                        {
                            elem.Enabled = true;
                        }
                        break;
                    case "blue":
                        foreach (var elem in blueChipsOutOfArea)
                        {
                            elem.Enabled = true;
                        }
                        break;
                }
            }

            buttonThrowDice.Enabled = false;

        }

        private void unableParticularChips(string color)
        {
            switch (color)
            {
                case "green":
                    pictureBoxGreen1.Enabled = false;
                    pictureBoxGreen2.Enabled = false;
                    pictureBoxGreen3.Enabled = false;
                    pictureBoxGreen4.Enabled = false;
                    break;
                case "blue":
                    pictureBoxBlue1.Enabled = false;
                    pictureBoxBlue2.Enabled = false;
                    pictureBoxBlue3.Enabled = false;
                    pictureBoxBlue4.Enabled = false;
                    break;
            }
            if (isAutomated && counter == playerWithComputerIdx)
            {
                counter++;
                turn();
            }
            else
            {
                buttonSkip.Enabled = false;
                buttonThrowDice.Enabled = true;
                counter++;
            }
            if (counter > allPlayers.Count - 1)
            {
                counter = 0;
            }
        }

        // dice throwings - main game funcs_______________________________________________________________________________________________

        private void buttonThrowDice_Click(object sender, EventArgs e)
        {
            pictureBoxDice.Visible = true;
            turn();
        }

        private void throwDice(int diceNum)
        {
            switch (diceNum)
            {
                case 1:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice1.jpg");
                    break;
                case 2:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice2.jpg");
                    break;
                case 3:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice3.jpg");
                    break;
                case 4:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice4.jpg");
                    break;
                case 5:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice5.jpg");
                    break;
                case 6:
                    pictureBoxDice.Image = Image.FromFile(@"C:\Users\Sailor\Downloads\dice6.jpg");
                    break;
            }
        }

        private void turn()
        {
            if (counter > allPlayers.Count - 1)
            {
                counter = 0;
            }
            labelTurn.Text = "TURN: " + allPlayers[counter].ToUpper();

            switch (allPlayers[counter])
            {
                case "green":
                    labelTurn.BackColor = Color.LightGreen;
                    break;
                case "blue":
                    labelTurn.BackColor = Color.LightBlue;
                    break;
            } //label color


            amountOfSteps = new Random().Next(1, 7);
            //amountOfSteps = 6;
            throwDice(amountOfSteps); // кидається кубик
            if (amountOfSteps == 6)
            {
                if (isAutomated && counter != playerWithComputerIdx)
                {
                    playersInGame[counter] = true;
                    Random rnd = new Random();
                    int idx = rnd.Next(0, 4);
                    while(excludeForPlayersChips.Contains(idx))
                    {
                        idx = rnd.Next(0, allGreenChips.Count);
                    }

                    if (allPlayers[counter] == "green")
                    {
                        moveChip(allGreenChips[idx], allGreenChips[idx].Location, idx);
                    }
                    else if (allPlayers[counter] == "blue")
                    {
                        moveChip(allBlueChips[idx], allBlueChips[idx].Location, idx);
                    }
                }
                else
                {
                    playersInGame[counter] = true;
                    enableAllPlayersChips(allPlayers[counter]);
                }
            }
            else
            {
                if (playersInGame[counter])
                {

                    if (blueChipsOutOfArea.Count != 0 && allPlayers[counter] == "blue")
                    {
                        if (isAutomated && counter != playerWithComputerIdx)
                        {
                            Random rnd = new Random();
                            int idx = rnd.Next(0, blueChipsOutOfArea.Count);
                            excludeForMoveChip.Add(idx);
                            moveChip(blueChipsOutOfArea[idx], blueChipsOutOfArea[idx].Location);
                            buttonThrowDice.Enabled = true;
                            excludeForMoveChip.Clear();
                        }
                        else
                        {
                            enableAllPlayersChips(allPlayers[counter]);
                        }
                    }
                    else if (greenChipsOutOfArea.Count != 0 && allPlayers[counter] == "green")
                    {
                        if (isAutomated && counter != playerWithComputerIdx)
                        {
                            Random rnd = new Random();
                            int idx = rnd.Next(0, greenChipsOutOfArea.Count);
                            excludeForMoveChip.Add(idx);
                            moveChip(greenChipsOutOfArea[idx], greenChipsOutOfArea[idx].Location);
                            buttonThrowDice.Enabled = true;
                            excludeForMoveChip.Clear();
                        }
                        else
                        {
                            enableAllPlayersChips(allPlayers[counter]);
                        }
                    }
                    else if (amountOfSteps != 6 && ((allPlayers[counter ]== "green") ? greenChipsOutOfArea.Count : blueChipsOutOfArea.Count) == 0)
                    {
                        buttonThrowDice.Enabled = true;
                        counter++;
                    }
                }
                else
                {
                    counter++;
                    if (isAutomated)
                    {
                        buttonThrowDice.Enabled = true;
                    }
                    if (counter > allPlayers.Count - 1)
                    {
                        counter = 0;
                    }
                }
            }
        }

        private void moveChip(PictureBox clickedPictureBox, Point currentPoint, int indexOfChipToBeExcluded=0)
        {
            if (counter > allPlayers.Count - 1)
            {
                counter = 0;
            }
            Point basePoint = new Point();
            if (greenChipsInArea.Contains(clickedPictureBox))
            {
                basePoint = greenBase;
            }
            else if (blueChipsInArea.Contains(clickedPictureBox))
            {
                basePoint = blueBase;
            }

            bool blocked = false;
            if (greenChipsInArea.Contains(clickedPictureBox) || blueChipsInArea.Contains(clickedPictureBox))
            {
                if (IsBlocked(clickedPictureBox, basePoint))
                {
                    if (isAutomated && counter != playerWithComputerIdx)
                    {
                        if (excludeForMoveChip.Count == ((allPlayers[counter] == "green") ? allGreenChips : allBlueChips).Count)
                        {
                            buttonSkip.Enabled = false;
                            buttonThrowDice.Enabled = true;
                            counter++;
                            if (counter > allPlayers.Count - 1)
                            {
                                counter = 0;
                            }
                            labelTurn.Text = "TURN: " + allPlayers[counter];
                            switch (allPlayers[counter])
                            {
                                case "green":
                                    labelTurn.BackColor = Color.LightGreen;
                                    break;
                                case "blue":
                                    labelTurn.BackColor = Color.LightBlue;
                                    break;
                            }
                        }
                        else
                        {
                            Random rand = new Random();
                            int newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? allGreenChips : allBlueChips).Count);

                            while (excludeForMoveChip.Contains(newIdx))
                            {
                                newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? allGreenChips : allBlueChips).Count);
                            }
                            excludeForMoveChip.Add(newIdx);

                            moveChip(
                                ((allPlayers[counter] == "green") ? allGreenChips : allBlueChips)[newIdx],
                                ((allPlayers[counter] == "green") ? allGreenChips : allBlueChips)[newIdx].Location);
                        }
                    }
                    else
                    {
                        MessageBox.Show("You can't move to base, because it is blocked");
                    }
                }
                else
                {
                    clickedPictureBox.Parent = pictureBoxDesk;
                    clickedPictureBox.Location = basePoint;
                    currentPoint = clickedPictureBox.Location;

                    if (IsBlocked(clickedPictureBox, currentPoint))
                    {
                        if (isAutomated && counter != playerWithComputerIdx)
                        {
                            if (excludeForMoveChip.Count == ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count)
                            {
                                buttonSkip.Enabled = false;
                                buttonThrowDice.Enabled = true;
                                counter++;
                            }
                            else
                            {
                                Random rand = new Random();
                                int newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);

                                while (excludeForMoveChip.Contains(newIdx))
                                {
                                    newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);
                                }
                                excludeForMoveChip.Add(newIdx);

                                moveChip(
                                    ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx],
                                    ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx].Location);
                            }
                        }
                        return;
                    }
                    else
                    {
                        if (isAutomated && counter != playerWithComputerIdx)
                        {
                            if(allPlayers[counter] == "green")
                            {
                                greenChipsInArea.Remove(clickedPictureBox);
                                greenChipsOutOfArea.Add(clickedPictureBox);
                            }
                            else if(allPlayers[counter] == "blue")
                            {
                                blueChipsInArea.Remove(clickedPictureBox);
                                blueChipsOutOfArea.Add(clickedPictureBox);
                            }
                            buttonSkip.Enabled = false;
                            buttonThrowDice.Enabled = true;
                        }
                        else
                        {
                            if (allPlayers[counter] == "green")
                            {
                                greenChipsInArea.Remove(clickedPictureBox);
                                greenChipsOutOfArea.Add(clickedPictureBox);
                            }
                            else if (allPlayers[counter] == "blue")
                            {
                                blueChipsInArea.Remove(clickedPictureBox);
                                blueChipsOutOfArea.Add(clickedPictureBox);
                            }
                        }
                    }
                }
                blocked = IsBlocked(clickedPictureBox, currentPoint);

            }
            else
            {
                clickedPictureBox.Parent = pictureBoxDesk;
                Point chipsCurrentPlace = clickedPictureBox.Location;
                int temp = 211;
                for (int i = 0; i < amountOfSteps; i++)
                {
                    if (
                    clickedPictureBox.Location.Y >= 175 &&
                    clickedPictureBox.Location.Y <= 246 &&
                    clickedPictureBox.Location.X <= 211
                    && clickedPictureBox.Location.X > 2)
                    {
                        if (allPlayers[counter] == "green" && greenDictChipsLoop[clickedPictureBox] == true && clickedPictureBox.Location == greenHomeEntrance)
                        {
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, temp + step);
                        }
                        else if (allPlayers[counter] == "green" && greenDictChipsLoop[clickedPictureBox] == true && clickedPictureBox.Location.Y == 246)
                        {
                            if (clickedPictureBox.Location.X + (amountOfSteps - i) * 35 == 211 || (amountOfSteps == 1 && clickedPictureBox.Location.X + (amountOfSteps - i) * 35 == 211))
                            {
                                clickedPictureBox.Location = new Point(211, 246);
                                clickedPictureBox.Enabled = false;
                                greenChipsOutOfArea.Remove(clickedPictureBox);
                                greenPlayedChips.Add(clickedPictureBox);
                                labelGreenPlayedChips.Text = greenPlayedChips.Count() + "/4";
                                if (isAutomated && counter != playerWithComputerIdx)
                                {
                                    excludeForPlayersChips.Add(indexOfChipToBeExcluded);
                                }
                                break;
                            }
                            else if (clickedPictureBox.Location.X + (amountOfSteps - i) * 35 < 211)
                            {
                                clickedPictureBox.Location = new Point(clickedPictureBox.Location.X + step, 246);
                            }
                            else if (clickedPictureBox.Location.X + (amountOfSteps - i) * 35 > 211)
                            {
                                if (isAutomated && counter != playerWithComputerIdx)
                                {
                                    if (excludeForMoveChip.Count == ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count)
                                    {
                                        buttonSkip.Enabled = false;
                                        buttonThrowDice.Enabled = true;
                                        counter++;
                                        return;
                                    }
                                    else
                                    {
                                        Random rand = new Random();
                                        int newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);

                                        while (excludeForMoveChip.Contains(newIdx))
                                        {
                                            newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);
                                        }
                                        excludeForMoveChip.Add(newIdx);

                                        moveChip(
                                            ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx],
                                            ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx].Location);
                                        break;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                        }
                        else if (clickedPictureBox.Location == greenHomeEntrance)
                        {
                            greenDictChipsLoop[clickedPictureBox] = true;
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X - step, 211);

                        }
                        else
                        {
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X - step, 211);

                        }
                    }
                    else if (clickedPictureBox.Location.Y <= 175 && clickedPictureBox.Location.X <= 221)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, clickedPictureBox.Location.Y + step);

                    }
                    else if (clickedPictureBox.Location.Y <= 270 && clickedPictureBox.Location.X <= 2)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, clickedPictureBox.Location.Y + step);
                    }
                    else if (clickedPictureBox.Location.Y >= 235 && clickedPictureBox.Location.X <= 175)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X + step, clickedPictureBox.Location.Y);


                    }
                    else if (clickedPictureBox.Location.Y >= 280
                        && clickedPictureBox.Location.Y <= 470
                        && clickedPictureBox.Location.X <= 211)
                    {
                        clickedPictureBox.Location = new Point(211, clickedPictureBox.Location.Y + step);


                    }
                    else if (clickedPictureBox.Location.Y == 491 && clickedPictureBox.Location.X < 281)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X + step, clickedPictureBox.Location.Y);


                    }
                    else if (clickedPictureBox.Location.Y > 316 && clickedPictureBox.Location.X <= 281)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, clickedPictureBox.Location.Y - step);


                    }
                    else if (clickedPictureBox.Location.Y > 212 && clickedPictureBox.Location.X == 491)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, clickedPictureBox.Location.Y - step);
                    }
                    else if (clickedPictureBox.Location.Y > 220 && clickedPictureBox.Location.X < 491 && clickedPictureBox.Location.X >= 281)
                    {

                        if (allPlayers[counter] == "blue" && blueDictChipsLoop[clickedPictureBox] == true && clickedPictureBox.Location == blueHomeEntrance)
                        {
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X, 281 - step);

                        }
                        else if (allPlayers[counter] == "blue" && blueDictChipsLoop[clickedPictureBox] == true && clickedPictureBox.Location.Y == 246)
                        {
                            if (clickedPictureBox.Location.X - (amountOfSteps - i) * 35 == 281 || amountOfSteps == 1 && clickedPictureBox.Location.X + (amountOfSteps - i) * 35 == 211)
                            {
                                clickedPictureBox.Location = new Point(281, 246);
                                clickedPictureBox.Enabled = false;
                                blueChipsOutOfArea.Remove(clickedPictureBox);
                                bluePlayedChips.Add(clickedPictureBox);
                                labelBluePlayedChips.Text = bluePlayedChips.Count() + "/4";
                                if (isAutomated && counter != playerWithComputerIdx)
                                {
                                    excludeForPlayersChips.Add(indexOfChipToBeExcluded);
                                }
                                break;
                            }
                            else if (clickedPictureBox.Location.X - (amountOfSteps - i) * 35 > 281)
                            {
                                clickedPictureBox.Location = new Point(clickedPictureBox.Location.X - step, 246);


                            }
                            else if (clickedPictureBox.Location.X - (amountOfSteps - i) * 35 < 281)
                            {
                                if (isAutomated && counter != playerWithComputerIdx)
                                {
                                    if (
                                        excludeForMoveChip.Count == ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count ||
                                        ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count == 0
                                        )
                                    {
                                        buttonSkip.Enabled = false;
                                        buttonThrowDice.Enabled = true;
                                        counter++;
                                        return;
                                    }
                                    else
                                    {
                                        Random rand = new Random();
                                        int newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);

                                        while (excludeForMoveChip.Contains(newIdx))
                                        {
                                            newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);
                                        }
                                        excludeForMoveChip.Add(newIdx);

                                        moveChip(
                                            ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx],
                                            ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx].Location);
                                        break;
                                    }
                                }
                                else
                                {
                                    return;
                                }
                            }
                        }
                        else if (clickedPictureBox.Location == blueHomeEntrance)
                        {
                            blueDictChipsLoop[clickedPictureBox] = true;
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X + step, 281);


                        }
                        else
                        {
                            clickedPictureBox.Location = new Point(clickedPictureBox.Location.X + step, 281);


                        }
                    }
                    else if (clickedPictureBox.Location.Y == 211 && clickedPictureBox.Location.X > 316)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X - step, 211);

                    }
                    else if (clickedPictureBox.Location.Y > 1 && clickedPictureBox.Location.X >= 281)
                    {
                        clickedPictureBox.Location = new Point(281, clickedPictureBox.Location.Y - step);


                    }
                    else if (clickedPictureBox.Location.Y == 1 && clickedPictureBox.Location.X <= 281)
                    {
                        clickedPictureBox.Location = new Point(clickedPictureBox.Location.X - step, clickedPictureBox.Location.Y);
                    }
                    blocked = IsBlocked(clickedPictureBox, currentPoint, (amountOfSteps - i - 1 == 0) ? true : false);
                }
            }

            if (blocked)
            {
                if (isAutomated && counter != playerWithComputerIdx)
                {
                    if (isAutomated && counter != playerWithComputerIdx)
                    {
                        if (
                            excludeForMoveChip.Count == ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count ||
                            ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count == 0
                            )
                        {
                            buttonSkip.Enabled = false;
                            buttonThrowDice.Enabled = true;

                            counter++;
                            return;
                        }
                        else
                        {
                            Random rand = new Random();
                            int newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);

                            while (excludeForMoveChip.Contains(newIdx))
                            {
                                newIdx = rand.Next(0, ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea).Count);
                            }
                            excludeForMoveChip.Add(newIdx);

                            moveChip(
                                ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx],
                                ((allPlayers[counter] == "green") ? greenChipsOutOfArea : blueChipsOutOfArea)[newIdx].Location);
                        }
                    }
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (isAutomated && counter != playerWithComputerIdx)
                {
                    buttonSkip.Enabled = false;
                    buttonThrowDice.Enabled = true;
                    counter++;
                    if (counter > allPlayers.Count - 1)
                    {
                        counter = 0;
                    }
                }
                else
                {
                    cutChip(clickedPictureBox);
                    if (counter > allPlayers.Count - 1)
                    {
                        counter = 0;
                    }
                    unableParticularChips(allPlayers[counter]);
                }
            }

            cutChip(clickedPictureBox);
            if (greenPlayedChips.Count == 4)
            {
                MessageBox.Show("OHOO. GREEN IS A WINNER!!");
                reset();
                return;
            }
            else if (bluePlayedChips.Count == 4)
            {
                MessageBox.Show("OHOO. BLUE IS A WINNER!!");
                reset();
                return;
            }
        }

        private void cutChip(PictureBox clickedPictureBox)
        {
            if (greenChipsOutOfArea.Contains(clickedPictureBox))
            {
                if (clickedPictureBox.Location == greenBase || clickedPictureBox.Location == blueBase)
                {
                    return;
                }
                else
                {
                    foreach (PictureBox c in blueChipsOutOfArea)
                    {
                        if (clickedPictureBox.Location == c.Location)
                        {
                            c.Parent = groupBoxBlue;
                            c.Location = blueDictChipsBasePos[c];
                            blueChipsInArea.Add(c);
                            blueChipsOutOfArea.Remove(c);
                            blueDictChipsLoop[c] = false;
                            break;
                        }
                    }
                }
            }
            else if (blueChipsOutOfArea.Contains(clickedPictureBox))
            {
                if (clickedPictureBox.Location == greenBase || clickedPictureBox.Location == blueBase)
                {
                    return;
                }
                else
                {
                    foreach (PictureBox c in greenChipsOutOfArea)
                    {
                        if (clickedPictureBox.Location == c.Location)
                        {
                            c.Parent = groupBoxGreen;
                            c.Location = greenDictChipsBasePos[c];
                            greenChipsInArea.Add(c);
                            greenChipsOutOfArea.Remove(c);
                            greenDictChipsLoop[c] = false;
                            break;
                        }
                    }
                }
            }
        }

        // context menu funcs_____________________________________________________________________________________________________________

        private void addPlayersToGame()
        {
            allPlayers.Clear();
            foreach (Control c in pictureBoxDesk.Controls.OfType<PictureBox>().ToList())
            {
                c.Visible = false;
            }

            groupBoxGreen.Visible = true;
            allPlayers.Add("green");
            playersInGame.Add(false);
            playersLoop.Add(false);
            foreach (PictureBox c in groupBoxGreen.Controls.OfType<PictureBox>())
            {
                greenDictChipsLoop[c] = false;
                greenDictChipsBasePos[c] = c.Location;
                allGreenChips.Add(c);
            }

            groupBoxBlue.Visible = true;
            allPlayers.Add("blue");
            playersInGame.Add(false);
            playersLoop.Add(false);
            foreach (PictureBox c in groupBoxBlue.Controls.OfType<PictureBox>())
            {
                blueDictChipsLoop[c] = false;
                blueDictChipsBasePos[c] = c.Location;
                allBlueChips.Add(c);
            }
        }

        private void reset()
        {
            buttonThrowDice.Enabled = true;
            for (int i = 0; i < playersInGame.Count; i++)
            {
                playersInGame[i] = false;
            }
            foreach (PictureBox c in pictureBoxDesk.Controls.OfType<PictureBox>().ToList())
            {
                if (groupBoxGreen.Contains(c) || greenChipsOutOfArea.Contains(c) || greenPlayedChips.Contains(c))
                {
                    c.Enabled = false;
                    c.Parent = groupBoxGreen;
                    c.Location = greenDictChipsBasePos[c];
                    greenDictChipsLoop[c] = false;
                    greenChipsOutOfArea.Remove(c);
                    greenPlayedChips.Remove(c);
                    greenChipsInArea.Add(c);
                }

                else if (groupBoxBlue.Contains(c) || blueChipsOutOfArea.Contains(c) || bluePlayedChips.Contains(c))
                {
                    c.Enabled = false;
                    c.Parent = groupBoxBlue;
                    c.Location = blueDictChipsBasePos[c];
                    blueDictChipsLoop[c] = false;
                    blueChipsOutOfArea.Remove(c);
                    bluePlayedChips.Remove(c);
                    blueChipsInArea.Add(c);
                }
            }
            labelTurn.Text = "TURN:";
            labelTurn.BackColor = Color.Transparent;
            labelGreenPlayedChips.Text = "0/4";
            labelBluePlayedChips.Text = "0/4";
            pictureBoxDice.Visible = false;
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reset();
        }


        // conditions for a game__________________________________________________________________________________________________________

        private bool IsBlocked(PictureBox pictureBoxInput, Point currentPoint, bool isIndexerZero = true)
        {
            int chipsOnCell = 0;
            foreach (Control c in pictureBoxDesk.Controls.OfType<PictureBox>().ToList())
            {
                if (pictureBoxInput.Location == c.Location)
                {
                    chipsOnCell++;
                }
            }
            if (chipsOnCell > 2)
            {
                bool isOneColorBlock = false;
                foreach (PictureBox pb in pictureBoxDesk.Controls.OfType<PictureBox>().ToArray())
                {
                    if (
                        greenChipsOutOfArea.Contains(pb) && allPlayers[counter] == "green" ||
                        blueChipsOutOfArea.Contains(pb) && allPlayers[counter] == "blue")
                    {
                        isOneColorBlock = true;
                        break;
                    }
                    else
                    {
                        pictureBoxInput.Location = currentPoint;
                    }
                }

                if (isOneColorBlock)
                {
                    if (isIndexerZero)
                    {
                        pictureBoxInput.Location = currentPoint;
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        // Chips moving___________________________________________________________________________________________________________________

        // Green
        private void pictureBoxGreen1_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            moveChip(clickedPictureBox, clickedPictureBox.Location);
        }

        private void pictureBoxGreen2_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            moveChip(clickedPictureBox, clickedPictureBox.Location);
        }

        private void pictureBoxGreen3_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            moveChip(clickedPictureBox, clickedPictureBox.Location);

        }

        private void pictureBoxGreen4_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            moveChip(clickedPictureBox, clickedPictureBox.Location);

        }


        // Red


        // Blue

        private void pictureBoxBlue1_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            Point currentPoint = clickedPictureBox.Location;
            moveChip(clickedPictureBox, currentPoint);
        }

        private void pictureBoxBlue2_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            Point currentPoint = clickedPictureBox.Location;
            moveChip(clickedPictureBox, currentPoint);
        }

        private void pictureBoxBlue3_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            Point currentPoint = clickedPictureBox.Location;
            moveChip(clickedPictureBox, currentPoint);
        }

        private void pictureBoxBlue4_MouseClick(object sender, MouseEventArgs e)
        {
            PictureBox clickedPictureBox = (PictureBox)sender;
            Point currentPoint = clickedPictureBox.Location;
            moveChip(clickedPictureBox, currentPoint);
        }

        private void buttonSkip_Click(object sender, EventArgs e)
        {
            if (counter > allPlayers.Count - 1)
            {
                counter = 0;
            }
            unableParticularChips(allPlayers[counter]);
            turn();
        }

        // intro form ____________________________________________________________________________________________________________________


        private void buttonPlayerVsComputer_Click(object sender, EventArgs e)
        {
            isAutomated = true;
            foreach (ComboBox cb in this.Controls.OfType<ComboBox>())
            {
                cb.Enabled = false;
                cb.Text = "";
            }
            playerWithComputerIdx = comboBoxIntroPlayerVsComputerColor.SelectedIndex;
            comboBoxIntroPlayerVsComputerColor.Enabled = true;
            comboBoxIntroPlayerVsComputerColor.Text = "select color";
        }

        private void buttonPlayerVsPlayer_Click(object sender, EventArgs e)
        {
            foreach (ComboBox cb in this.Controls.OfType<ComboBox>())
            {
                cb.Enabled = false;
                cb.Text = "";
            }
            comboBoxIntroPlayerVsPlayerOne.Enabled = true;
            comboBoxIntroPlayerVsPlayerOne.Text = "select color";
            comboBoxIntroPlayerVsPlayerTwo.Enabled = true;
            comboBoxIntroPlayerVsPlayerTwo.Text = "select color";
        }

        private void comboBoxPlayerVsComputerColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxIntroPlayerVsPlayerOne.Text = "";
            comboBoxIntroPlayerVsPlayerOne.Enabled = false;
            comboBoxIntroPlayerVsPlayerTwo.Text = "";
            comboBoxIntroPlayerVsPlayerTwo.Enabled = false;

            playerWithComputerIdx = comboBoxIntroPlayerVsComputerColor.SelectedIndex;
            buttonIntroStart.Enabled = true;
        }

        private void comboBoxPlayerVsPlayerOne_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxIntroPlayerVsComputerColor.Text = "";
            comboBoxIntroPlayerVsComputerColor.Enabled = false;

            firstPlayerIdx = comboBoxIntroPlayerVsPlayerOne.SelectedIndex;
            comboBoxIntroPlayerVsPlayerTwo.SelectedIndex = comboBoxIntroPlayerVsPlayerOne.Items.Count - firstPlayerIdx - 1;
            secondPlayerIdx = comboBoxIntroPlayerVsComputerColor.Items.Count - firstPlayerIdx - 1;
            buttonIntroStart.Enabled = true;
        }

        private void comboBoxPlayerVsPlayerTwo_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxIntroPlayerVsComputerColor.Text = "";
            comboBoxIntroPlayerVsComputerColor.Enabled = false;

            secondPlayerIdx = comboBoxIntroPlayerVsPlayerTwo.SelectedIndex;
            comboBoxIntroPlayerVsPlayerOne.SelectedIndex = comboBoxIntroPlayerVsPlayerOne.Items.Count - secondPlayerIdx - 1;
            firstPlayerIdx = comboBoxIntroPlayerVsComputerColor.Items.Count - secondPlayerIdx - 1;
            buttonIntroStart.Enabled = true;
        }

        private void buttonIntroStart_Click(object sender, EventArgs e)
        {
            reallyClose = false;
            if (comboBoxIntroPlayerVsPlayerOne.SelectedIndex != -1 || comboBoxIntroPlayerVsComputerColor.SelectedIndex != -1)
            {
                foreach (ComboBox cb in this.Controls.OfType<ComboBox>())
                {
                    cb.Visible = false;
                }
                buttonIntroPlayerVsComputer.Visible = false;
                buttonIntroPlayerVsPlayer.Visible = false;
                labelIntoGameName.Visible = false;
                labelIntroSlogan.Visible = false;
                buttonIntroStart.Visible = false;
                buttonThrowDice.Enabled = true;
                panelMainControls.Visible = true;
                pictureBoxDesk.Visible = true;
                menuStrip1.Visible = true;
                addPlayersToGame();
                do
                {
                    counter = new Random().Next(0, allPlayers.Count);
                } while (counter != playerWithComputerIdx);

                if (isAutomated && counter != playerWithComputerIdx)
                {
                    buttonThrowDice.Enabled = false;
                    turn();
                }
            }
            else
            {
                MessageBox.Show("Please, choose rejime and your color first!");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            reset();
            allPlayers.Clear();
            playersInGame.Clear();
            playersLoop.Clear();
            foreach (ComboBox cb in this.Controls.OfType<ComboBox>())
            {
                cb.Visible = true;
            }
            buttonIntroPlayerVsComputer.Visible = true;
            buttonIntroPlayerVsPlayer.Visible = true;
            labelIntoGameName.Visible = true;
            labelIntroSlogan.Visible = true;
            buttonIntroStart.Visible = true;
            isAutomated = false;
            foreach (ComboBox cb in this.Controls.OfType<ComboBox>())
            {
                cb.SelectedIndex = -1;
                cb.Enabled = false;
                cb.Text = "";
            }

            buttonIntroStart.Enabled = false;
            buttonThrowDice.Enabled = false;
            panelMainControls.Visible = false;
            pictureBoxDesk.Visible = false;
            menuStrip1.Visible = false;

            if (!reallyClose)
            {
                e.Cancel = true;
                reallyClose = true;
            }
        }

        // additional funcs_______________________________________________________________________________________________________________
    }
}
