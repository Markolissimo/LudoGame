﻿namespace LudoGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBoxDesk = new System.Windows.Forms.PictureBox();
            this.panelMainControls = new System.Windows.Forms.Panel();
            this.buttonSkip = new System.Windows.Forms.Button();
            this.labelTurn = new System.Windows.Forms.Label();
            this.buttonThrowDice = new System.Windows.Forms.Button();
            this.pictureBoxDice = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBoxBlue1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxBlue2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxBlue3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxBlue4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxYellow1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxYellow2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxYellow3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxYellow4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxRed1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxRed2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxRed3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxRed4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGreen4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGreen3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGreen2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxGreen1 = new System.Windows.Forms.PictureBox();
            this.groupBoxGreen = new System.Windows.Forms.GroupBox();
            this.groupBoxBlue = new System.Windows.Forms.GroupBox();
            this.labelIntoGameName = new System.Windows.Forms.Label();
            this.labelIntroSlogan = new System.Windows.Forms.Label();
            this.buttonIntroPlayerVsComputer = new System.Windows.Forms.Button();
            this.buttonIntroPlayerVsPlayer = new System.Windows.Forms.Button();
            this.comboBoxIntroPlayerVsComputerColor = new System.Windows.Forms.ComboBox();
            this.comboBoxIntroPlayerVsPlayerOne = new System.Windows.Forms.ComboBox();
            this.comboBoxIntroPlayerVsPlayerTwo = new System.Windows.Forms.ComboBox();
            this.buttonIntroStart = new System.Windows.Forms.Button();
            this.labelGreenPlayedChips = new System.Windows.Forms.Label();
            this.labelBluePlayedChips = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDesk)).BeginInit();
            this.panelMainControls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDice)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen1)).BeginInit();
            this.groupBoxGreen.SuspendLayout();
            this.groupBoxBlue.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxDesk
            // 
            this.pictureBoxDesk.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxDesk.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxDesk.Image")));
            this.pictureBoxDesk.Location = new System.Drawing.Point(1, 27);
            this.pictureBoxDesk.Name = "pictureBoxDesk";
            this.pictureBoxDesk.Size = new System.Drawing.Size(543, 533);
            this.pictureBoxDesk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDesk.TabIndex = 0;
            this.pictureBoxDesk.TabStop = false;
            this.pictureBoxDesk.Visible = false;
            // 
            // panelMainControls
            // 
            this.panelMainControls.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelMainControls.BackColor = System.Drawing.Color.Moccasin;
            this.panelMainControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMainControls.Controls.Add(this.panel2);
            this.panelMainControls.Controls.Add(this.panel1);
            this.panelMainControls.Controls.Add(this.buttonSkip);
            this.panelMainControls.Controls.Add(this.labelTurn);
            this.panelMainControls.Controls.Add(this.buttonThrowDice);
            this.panelMainControls.Controls.Add(this.pictureBoxDice);
            this.panelMainControls.Location = new System.Drawing.Point(526, 27);
            this.panelMainControls.Name = "panelMainControls";
            this.panelMainControls.Size = new System.Drawing.Size(260, 533);
            this.panelMainControls.TabIndex = 1;
            this.panelMainControls.Visible = false;
            // 
            // buttonSkip
            // 
            this.buttonSkip.BackColor = System.Drawing.Color.Silver;
            this.buttonSkip.Enabled = false;
            this.buttonSkip.Location = new System.Drawing.Point(170, 187);
            this.buttonSkip.Name = "buttonSkip";
            this.buttonSkip.Size = new System.Drawing.Size(75, 23);
            this.buttonSkip.TabIndex = 3;
            this.buttonSkip.Text = "skip a turn";
            this.buttonSkip.UseVisualStyleBackColor = false;
            this.buttonSkip.Click += new System.EventHandler(this.buttonSkip_Click);
            // 
            // labelTurn
            // 
            this.labelTurn.AutoSize = true;
            this.labelTurn.BackColor = System.Drawing.Color.NavajoWhite;
            this.labelTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTurn.Location = new System.Drawing.Point(10, 193);
            this.labelTurn.Name = "labelTurn";
            this.labelTurn.Size = new System.Drawing.Size(56, 17);
            this.labelTurn.TabIndex = 2;
            this.labelTurn.Text = "TURN:";
            // 
            // buttonThrowDice
            // 
            this.buttonThrowDice.BackColor = System.Drawing.Color.GhostWhite;
            this.buttonThrowDice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonThrowDice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonThrowDice.ForeColor = System.Drawing.Color.Black;
            this.buttonThrowDice.Location = new System.Drawing.Point(44, 14);
            this.buttonThrowDice.Name = "buttonThrowDice";
            this.buttonThrowDice.Size = new System.Drawing.Size(169, 50);
            this.buttonThrowDice.TabIndex = 1;
            this.buttonThrowDice.Text = "THROW DICE";
            this.buttonThrowDice.UseVisualStyleBackColor = false;
            this.buttonThrowDice.Click += new System.EventHandler(this.buttonThrowDice_Click);
            // 
            // pictureBoxDice
            // 
            this.pictureBoxDice.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBoxDice.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBoxDice.Location = new System.Drawing.Point(94, 451);
            this.pictureBoxDice.Name = "pictureBoxDice";
            this.pictureBoxDice.Size = new System.Drawing.Size(70, 70);
            this.pictureBoxDice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDice.TabIndex = 0;
            this.pictureBoxDice.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // pictureBoxBlue1
            // 
            this.pictureBoxBlue1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBlue1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxBlue1.Enabled = false;
            this.pictureBoxBlue1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBlue1.Image")));
            this.pictureBoxBlue1.Location = new System.Drawing.Point(27, 32);
            this.pictureBoxBlue1.Name = "pictureBoxBlue1";
            this.pictureBoxBlue1.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxBlue1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBlue1.TabIndex = 7;
            this.pictureBoxBlue1.TabStop = false;
            this.pictureBoxBlue1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxBlue1_MouseClick);
            // 
            // pictureBoxBlue2
            // 
            this.pictureBoxBlue2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBlue2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxBlue2.Enabled = false;
            this.pictureBoxBlue2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBlue2.Image")));
            this.pictureBoxBlue2.Location = new System.Drawing.Point(78, 32);
            this.pictureBoxBlue2.Name = "pictureBoxBlue2";
            this.pictureBoxBlue2.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxBlue2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBlue2.TabIndex = 8;
            this.pictureBoxBlue2.TabStop = false;
            this.pictureBoxBlue2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxBlue2_MouseClick);
            // 
            // pictureBoxBlue3
            // 
            this.pictureBoxBlue3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBlue3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxBlue3.Enabled = false;
            this.pictureBoxBlue3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBlue3.Image")));
            this.pictureBoxBlue3.Location = new System.Drawing.Point(27, 88);
            this.pictureBoxBlue3.Name = "pictureBoxBlue3";
            this.pictureBoxBlue3.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxBlue3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBlue3.TabIndex = 9;
            this.pictureBoxBlue3.TabStop = false;
            this.pictureBoxBlue3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxBlue3_MouseClick);
            // 
            // pictureBoxBlue4
            // 
            this.pictureBoxBlue4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBlue4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxBlue4.Enabled = false;
            this.pictureBoxBlue4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBlue4.Image")));
            this.pictureBoxBlue4.Location = new System.Drawing.Point(78, 88);
            this.pictureBoxBlue4.Name = "pictureBoxBlue4";
            this.pictureBoxBlue4.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxBlue4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBlue4.TabIndex = 10;
            this.pictureBoxBlue4.TabStop = false;
            this.pictureBoxBlue4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxBlue4_MouseClick);
            // 
            // pictureBoxYellow1
            // 
            this.pictureBoxYellow1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxYellow1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxYellow1.Enabled = false;
            this.pictureBoxYellow1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxYellow1.Image")));
            this.pictureBoxYellow1.Location = new System.Drawing.Point(380, 57);
            this.pictureBoxYellow1.Name = "pictureBoxYellow1";
            this.pictureBoxYellow1.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxYellow1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxYellow1.TabIndex = 11;
            this.pictureBoxYellow1.TabStop = false;
            this.pictureBoxYellow1.Visible = false;
            // 
            // pictureBoxYellow2
            // 
            this.pictureBoxYellow2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxYellow2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxYellow2.Enabled = false;
            this.pictureBoxYellow2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxYellow2.Image")));
            this.pictureBoxYellow2.Location = new System.Drawing.Point(442, 57);
            this.pictureBoxYellow2.Name = "pictureBoxYellow2";
            this.pictureBoxYellow2.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxYellow2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxYellow2.TabIndex = 12;
            this.pictureBoxYellow2.TabStop = false;
            this.pictureBoxYellow2.Visible = false;
            // 
            // pictureBoxYellow3
            // 
            this.pictureBoxYellow3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxYellow3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxYellow3.Enabled = false;
            this.pictureBoxYellow3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxYellow3.Image")));
            this.pictureBoxYellow3.Location = new System.Drawing.Point(380, 128);
            this.pictureBoxYellow3.Name = "pictureBoxYellow3";
            this.pictureBoxYellow3.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxYellow3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxYellow3.TabIndex = 13;
            this.pictureBoxYellow3.TabStop = false;
            this.pictureBoxYellow3.Visible = false;
            // 
            // pictureBoxYellow4
            // 
            this.pictureBoxYellow4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxYellow4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxYellow4.Enabled = false;
            this.pictureBoxYellow4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxYellow4.Image")));
            this.pictureBoxYellow4.Location = new System.Drawing.Point(442, 128);
            this.pictureBoxYellow4.Name = "pictureBoxYellow4";
            this.pictureBoxYellow4.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxYellow4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxYellow4.TabIndex = 14;
            this.pictureBoxYellow4.TabStop = false;
            this.pictureBoxYellow4.Visible = false;
            // 
            // pictureBoxRed1
            // 
            this.pictureBoxRed1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxRed1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRed1.Enabled = false;
            this.pictureBoxRed1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRed1.Image")));
            this.pictureBoxRed1.Location = new System.Drawing.Point(63, 375);
            this.pictureBoxRed1.Name = "pictureBoxRed1";
            this.pictureBoxRed1.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxRed1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRed1.TabIndex = 15;
            this.pictureBoxRed1.TabStop = false;
            this.pictureBoxRed1.Visible = false;
            // 
            // pictureBoxRed2
            // 
            this.pictureBoxRed2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxRed2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRed2.Enabled = false;
            this.pictureBoxRed2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRed2.Image")));
            this.pictureBoxRed2.Location = new System.Drawing.Point(125, 375);
            this.pictureBoxRed2.Name = "pictureBoxRed2";
            this.pictureBoxRed2.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxRed2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRed2.TabIndex = 16;
            this.pictureBoxRed2.TabStop = false;
            this.pictureBoxRed2.Visible = false;
            // 
            // pictureBoxRed3
            // 
            this.pictureBoxRed3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxRed3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRed3.Enabled = false;
            this.pictureBoxRed3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRed3.Image")));
            this.pictureBoxRed3.Location = new System.Drawing.Point(63, 446);
            this.pictureBoxRed3.Name = "pictureBoxRed3";
            this.pictureBoxRed3.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxRed3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRed3.TabIndex = 17;
            this.pictureBoxRed3.TabStop = false;
            this.pictureBoxRed3.Visible = false;
            // 
            // pictureBoxRed4
            // 
            this.pictureBoxRed4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxRed4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRed4.Enabled = false;
            this.pictureBoxRed4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRed4.Image")));
            this.pictureBoxRed4.Location = new System.Drawing.Point(125, 446);
            this.pictureBoxRed4.Name = "pictureBoxRed4";
            this.pictureBoxRed4.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxRed4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRed4.TabIndex = 18;
            this.pictureBoxRed4.TabStop = false;
            this.pictureBoxRed4.Visible = false;
            // 
            // pictureBoxGreen4
            // 
            this.pictureBoxGreen4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGreen4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGreen4.Enabled = false;
            this.pictureBoxGreen4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGreen4.Image")));
            this.pictureBoxGreen4.Location = new System.Drawing.Point(78, 86);
            this.pictureBoxGreen4.Name = "pictureBoxGreen4";
            this.pictureBoxGreen4.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxGreen4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGreen4.TabIndex = 6;
            this.pictureBoxGreen4.TabStop = false;
            this.pictureBoxGreen4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxGreen4_MouseClick);
            // 
            // pictureBoxGreen3
            // 
            this.pictureBoxGreen3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGreen3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGreen3.Enabled = false;
            this.pictureBoxGreen3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGreen3.Image")));
            this.pictureBoxGreen3.Location = new System.Drawing.Point(27, 86);
            this.pictureBoxGreen3.Name = "pictureBoxGreen3";
            this.pictureBoxGreen3.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxGreen3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGreen3.TabIndex = 5;
            this.pictureBoxGreen3.TabStop = false;
            this.pictureBoxGreen3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxGreen3_MouseClick);
            // 
            // pictureBoxGreen2
            // 
            this.pictureBoxGreen2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGreen2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxGreen2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGreen2.Enabled = false;
            this.pictureBoxGreen2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGreen2.Image")));
            this.pictureBoxGreen2.Location = new System.Drawing.Point(78, 30);
            this.pictureBoxGreen2.Name = "pictureBoxGreen2";
            this.pictureBoxGreen2.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxGreen2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGreen2.TabIndex = 4;
            this.pictureBoxGreen2.TabStop = false;
            this.pictureBoxGreen2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxGreen2_MouseClick);
            // 
            // pictureBoxGreen1
            // 
            this.pictureBoxGreen1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGreen1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxGreen1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxGreen1.Enabled = false;
            this.pictureBoxGreen1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGreen1.Image")));
            this.pictureBoxGreen1.Location = new System.Drawing.Point(27, 30);
            this.pictureBoxGreen1.Name = "pictureBoxGreen1";
            this.pictureBoxGreen1.Size = new System.Drawing.Size(35, 35);
            this.pictureBoxGreen1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxGreen1.TabIndex = 3;
            this.pictureBoxGreen1.TabStop = false;
            this.pictureBoxGreen1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBoxGreen1_MouseClick);
            // 
            // groupBoxGreen
            // 
            this.groupBoxGreen.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxGreen.Controls.Add(this.pictureBoxGreen1);
            this.groupBoxGreen.Controls.Add(this.pictureBoxGreen2);
            this.groupBoxGreen.Controls.Add(this.pictureBoxGreen3);
            this.groupBoxGreen.Controls.Add(this.pictureBoxGreen4);
            this.groupBoxGreen.Location = new System.Drawing.Point(36, 27);
            this.groupBoxGreen.Name = "groupBoxGreen";
            this.groupBoxGreen.Size = new System.Drawing.Size(143, 146);
            this.groupBoxGreen.TabIndex = 19;
            this.groupBoxGreen.TabStop = false;
            this.groupBoxGreen.Visible = false;
            // 
            // groupBoxBlue
            // 
            this.groupBoxBlue.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxBlue.Controls.Add(this.pictureBoxBlue1);
            this.groupBoxBlue.Controls.Add(this.pictureBoxBlue2);
            this.groupBoxBlue.Controls.Add(this.pictureBoxBlue3);
            this.groupBoxBlue.Controls.Add(this.pictureBoxBlue4);
            this.groupBoxBlue.Location = new System.Drawing.Point(353, 343);
            this.groupBoxBlue.Name = "groupBoxBlue";
            this.groupBoxBlue.Size = new System.Drawing.Size(143, 146);
            this.groupBoxBlue.TabIndex = 20;
            this.groupBoxBlue.TabStop = false;
            this.groupBoxBlue.Visible = false;
            // 
            // labelIntoGameName
            // 
            this.labelIntoGameName.AutoSize = true;
            this.labelIntoGameName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelIntoGameName.Location = new System.Drawing.Point(12, 9);
            this.labelIntoGameName.Name = "labelIntoGameName";
            this.labelIntoGameName.Size = new System.Drawing.Size(100, 17);
            this.labelIntoGameName.TabIndex = 21;
            this.labelIntoGameName.Text = "LUDO GAME";
            // 
            // labelIntroSlogan
            // 
            this.labelIntroSlogan.AutoSize = true;
            this.labelIntroSlogan.BackColor = System.Drawing.Color.White;
            this.labelIntroSlogan.Font = new System.Drawing.Font("Tw Cen MT", 25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIntroSlogan.Location = new System.Drawing.Point(185, 134);
            this.labelIntroSlogan.Name = "labelIntroSlogan";
            this.labelIntroSlogan.Size = new System.Drawing.Size(377, 39);
            this.labelIntroSlogan.TabIndex = 22;
            this.labelIntroSlogan.Text = "CONQUER AND GET FUN!!";
            // 
            // buttonIntroPlayerVsComputer
            // 
            this.buttonIntroPlayerVsComputer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonIntroPlayerVsComputer.Location = new System.Drawing.Point(227, 205);
            this.buttonIntroPlayerVsComputer.Name = "buttonIntroPlayerVsComputer";
            this.buttonIntroPlayerVsComputer.Size = new System.Drawing.Size(294, 60);
            this.buttonIntroPlayerVsComputer.TabIndex = 23;
            this.buttonIntroPlayerVsComputer.Text = "PLAYER VS COMPUTER";
            this.buttonIntroPlayerVsComputer.UseVisualStyleBackColor = true;
            this.buttonIntroPlayerVsComputer.Click += new System.EventHandler(this.buttonPlayerVsComputer_Click);
            // 
            // buttonIntroPlayerVsPlayer
            // 
            this.buttonIntroPlayerVsPlayer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonIntroPlayerVsPlayer.Location = new System.Drawing.Point(227, 305);
            this.buttonIntroPlayerVsPlayer.Name = "buttonIntroPlayerVsPlayer";
            this.buttonIntroPlayerVsPlayer.Size = new System.Drawing.Size(294, 60);
            this.buttonIntroPlayerVsPlayer.TabIndex = 24;
            this.buttonIntroPlayerVsPlayer.Text = "PLAYER VS PLAYER";
            this.buttonIntroPlayerVsPlayer.UseVisualStyleBackColor = true;
            this.buttonIntroPlayerVsPlayer.Click += new System.EventHandler(this.buttonPlayerVsPlayer_Click);
            // 
            // comboBoxIntroPlayerVsComputerColor
            // 
            this.comboBoxIntroPlayerVsComputerColor.Enabled = false;
            this.comboBoxIntroPlayerVsComputerColor.FormattingEnabled = true;
            this.comboBoxIntroPlayerVsComputerColor.Items.AddRange(new object[] {
            "green",
            "blue"});
            this.comboBoxIntroPlayerVsComputerColor.Location = new System.Drawing.Point(323, 271);
            this.comboBoxIntroPlayerVsComputerColor.Name = "comboBoxIntroPlayerVsComputerColor";
            this.comboBoxIntroPlayerVsComputerColor.Size = new System.Drawing.Size(100, 21);
            this.comboBoxIntroPlayerVsComputerColor.TabIndex = 25;
            this.comboBoxIntroPlayerVsComputerColor.SelectedIndexChanged += new System.EventHandler(this.comboBoxPlayerVsComputerColor_SelectedIndexChanged);
            // 
            // comboBoxIntroPlayerVsPlayerOne
            // 
            this.comboBoxIntroPlayerVsPlayerOne.Enabled = false;
            this.comboBoxIntroPlayerVsPlayerOne.FormattingEnabled = true;
            this.comboBoxIntroPlayerVsPlayerOne.Items.AddRange(new object[] {
            "green",
            "blue"});
            this.comboBoxIntroPlayerVsPlayerOne.Location = new System.Drawing.Point(227, 371);
            this.comboBoxIntroPlayerVsPlayerOne.Name = "comboBoxIntroPlayerVsPlayerOne";
            this.comboBoxIntroPlayerVsPlayerOne.Size = new System.Drawing.Size(100, 21);
            this.comboBoxIntroPlayerVsPlayerOne.TabIndex = 26;
            this.comboBoxIntroPlayerVsPlayerOne.SelectedIndexChanged += new System.EventHandler(this.comboBoxPlayerVsPlayerOne_SelectedIndexChanged);
            // 
            // comboBoxIntroPlayerVsPlayerTwo
            // 
            this.comboBoxIntroPlayerVsPlayerTwo.Enabled = false;
            this.comboBoxIntroPlayerVsPlayerTwo.FormattingEnabled = true;
            this.comboBoxIntroPlayerVsPlayerTwo.Items.AddRange(new object[] {
            "green",
            "blue"});
            this.comboBoxIntroPlayerVsPlayerTwo.Location = new System.Drawing.Point(421, 371);
            this.comboBoxIntroPlayerVsPlayerTwo.Name = "comboBoxIntroPlayerVsPlayerTwo";
            this.comboBoxIntroPlayerVsPlayerTwo.Size = new System.Drawing.Size(100, 21);
            this.comboBoxIntroPlayerVsPlayerTwo.TabIndex = 27;
            this.comboBoxIntroPlayerVsPlayerTwo.SelectedIndexChanged += new System.EventHandler(this.comboBoxPlayerVsPlayerTwo_SelectedIndexChanged);
            // 
            // buttonIntroStart
            // 
            this.buttonIntroStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonIntroStart.Enabled = false;
            this.buttonIntroStart.Location = new System.Drawing.Point(323, 434);
            this.buttonIntroStart.Name = "buttonIntroStart";
            this.buttonIntroStart.Size = new System.Drawing.Size(100, 50);
            this.buttonIntroStart.TabIndex = 28;
            this.buttonIntroStart.Text = "START";
            this.buttonIntroStart.UseMnemonic = false;
            this.buttonIntroStart.UseVisualStyleBackColor = true;
            this.buttonIntroStart.Click += new System.EventHandler(this.buttonIntroStart_Click);
            // 
            // labelGreenPlayedChips
            // 
            this.labelGreenPlayedChips.AutoSize = true;
            this.labelGreenPlayedChips.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelGreenPlayedChips.Location = new System.Drawing.Point(26, 42);
            this.labelGreenPlayedChips.Name = "labelGreenPlayedChips";
            this.labelGreenPlayedChips.Size = new System.Drawing.Size(43, 25);
            this.labelGreenPlayedChips.TabIndex = 4;
            this.labelGreenPlayedChips.Text = "0/4";
            // 
            // labelBluePlayedChips
            // 
            this.labelBluePlayedChips.AutoSize = true;
            this.labelBluePlayedChips.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBluePlayedChips.Location = new System.Drawing.Point(25, 42);
            this.labelBluePlayedChips.Name = "labelBluePlayedChips";
            this.labelBluePlayedChips.Size = new System.Drawing.Size(43, 25);
            this.labelBluePlayedChips.TabIndex = 5;
            this.labelBluePlayedChips.Text = "0/4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "GREEN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(3, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "BLUE";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.labelGreenPlayedChips);
            this.panel1.Location = new System.Drawing.Point(13, 315);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(95, 100);
            this.panel1.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.Controls.Add(this.labelBluePlayedChips);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(150, 315);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(95, 100);
            this.panel2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.buttonIntroStart);
            this.Controls.Add(this.comboBoxIntroPlayerVsPlayerTwo);
            this.Controls.Add(this.comboBoxIntroPlayerVsPlayerOne);
            this.Controls.Add(this.comboBoxIntroPlayerVsComputerColor);
            this.Controls.Add(this.buttonIntroPlayerVsPlayer);
            this.Controls.Add(this.buttonIntroPlayerVsComputer);
            this.Controls.Add(this.labelIntroSlogan);
            this.Controls.Add(this.labelIntoGameName);
            this.Controls.Add(this.groupBoxBlue);
            this.Controls.Add(this.groupBoxGreen);
            this.Controls.Add(this.pictureBoxRed4);
            this.Controls.Add(this.pictureBoxRed3);
            this.Controls.Add(this.pictureBoxRed2);
            this.Controls.Add(this.pictureBoxRed1);
            this.Controls.Add(this.pictureBoxYellow4);
            this.Controls.Add(this.pictureBoxYellow3);
            this.Controls.Add(this.pictureBoxYellow2);
            this.Controls.Add(this.pictureBoxYellow1);
            this.Controls.Add(this.panelMainControls);
            this.Controls.Add(this.pictureBoxDesk);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDesk)).EndInit();
            this.panelMainControls.ResumeLayout(false);
            this.panelMainControls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDice)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlue4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxYellow4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRed4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGreen1)).EndInit();
            this.groupBoxGreen.ResumeLayout(false);
            this.groupBoxBlue.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxDesk;
        private System.Windows.Forms.Panel panelMainControls;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBoxBlue1;
        private System.Windows.Forms.PictureBox pictureBoxBlue2;
        private System.Windows.Forms.PictureBox pictureBoxBlue3;
        private System.Windows.Forms.PictureBox pictureBoxBlue4;
        private System.Windows.Forms.PictureBox pictureBoxYellow1;
        private System.Windows.Forms.PictureBox pictureBoxYellow2;
        private System.Windows.Forms.PictureBox pictureBoxYellow3;
        private System.Windows.Forms.PictureBox pictureBoxYellow4;
        private System.Windows.Forms.PictureBox pictureBoxRed1;
        private System.Windows.Forms.PictureBox pictureBoxRed2;
        private System.Windows.Forms.PictureBox pictureBoxRed3;
        private System.Windows.Forms.PictureBox pictureBoxRed4;
        private System.Windows.Forms.PictureBox pictureBoxDice;
        private System.Windows.Forms.Button buttonThrowDice;
        private System.Windows.Forms.Label labelTurn;
        private System.Windows.Forms.PictureBox pictureBoxGreen4;
        private System.Windows.Forms.PictureBox pictureBoxGreen3;
        private System.Windows.Forms.PictureBox pictureBoxGreen2;
        private System.Windows.Forms.PictureBox pictureBoxGreen1;
        private System.Windows.Forms.GroupBox groupBoxGreen;
        private System.Windows.Forms.GroupBox groupBoxBlue;
        private System.Windows.Forms.Button buttonSkip;
        private System.Windows.Forms.Label labelIntoGameName;
        private System.Windows.Forms.Label labelIntroSlogan;
        private System.Windows.Forms.Button buttonIntroPlayerVsComputer;
        private System.Windows.Forms.Button buttonIntroPlayerVsPlayer;
        private System.Windows.Forms.ComboBox comboBoxIntroPlayerVsPlayerTwo;
        private System.Windows.Forms.ComboBox comboBoxIntroPlayerVsComputerColor;
        private System.Windows.Forms.ComboBox comboBoxIntroPlayerVsPlayerOne;
        private System.Windows.Forms.Button buttonIntroStart;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelBluePlayedChips;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelGreenPlayedChips;
    }
}

